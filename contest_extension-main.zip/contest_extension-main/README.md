# contest-extension
this is chrome extension that is used for update of current and future contests on sites like codechef,hackerrank,hackerearth etc.
chrome extension based on notifications of challenges being conducted (upcoming and running) on the various coding sites.
this extension will help coders to click only at the icon and they gets the details of various competitions on the
pop up window.
